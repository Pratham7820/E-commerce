
const router = require("express").Router()
router.get("/", (req,res)=>{
  res.json([{_id:1,title:"Demo Product",price:999}])
})
module.exports = router
