
const router = require("express").Router()
const { createPaymentIntent } = require("../controllers/payment.controller")
router.post("/create-payment-intent", createPaymentIntent)
module.exports = router
