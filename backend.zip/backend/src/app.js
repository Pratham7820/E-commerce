
const express = require("express")
const cors = require("cors")
const mongoose = require("mongoose")

mongoose.connect(process.env.MONGO_URI)

const app = express()
app.use(cors())
app.use(express.json())

app.use("/api/products", require("./routes/product.routes"))
app.use("/api/payment", require("./routes/payment.routes"))

module.exports = app
