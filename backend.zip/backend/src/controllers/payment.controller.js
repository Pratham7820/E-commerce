
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY)
exports.createPaymentIntent = async (req,res) => {
  const intent = await stripe.paymentIntents.create({
    amount: req.body.amount,
    currency: "inr",
    automatic_payment_methods: { enabled: true }
  })
  res.json({ clientSecret: intent.client_secret })
}
