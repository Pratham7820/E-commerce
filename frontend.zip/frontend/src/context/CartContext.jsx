
import { createContext, useState } from "react"
export const CartContext = createContext()

export function CartProvider({ children }) {
  const [cart, setCart] = useState([])
  return (
    <CartContext.Provider value={{
      cart,
      addToCart: (p) => setCart([...cart, p]),
      removeFromCart: (i) => setCart(cart.filter((_,x)=>x!==i))
    }}>
      {children}
    </CartContext.Provider>
  )
}
