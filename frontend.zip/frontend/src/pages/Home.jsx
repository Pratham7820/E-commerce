
import axios from "axios"
import { useEffect, useState, useContext } from "react"
import { CartContext } from "../context/CartContext"

export default function Home() {
  const [products, setProducts] = useState([])
  const { addToCart } = useContext(CartContext)

  useEffect(() => {
    axios.get("http://localhost:5000/api/products")
      .then(res => setProducts(res.data))
  }, [])

  return (
    <div>
      <h1>Products</h1>
      {products.map(p => (
        <div key={p._id}>
          <h3>{p.title}</h3>
          <p>₹{p.price}</p>
          <button onClick={() => addToCart(p)}>Add</button>
        </div>
      ))}
    </div>
  )
}
