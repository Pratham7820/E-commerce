
import { useContext } from "react"
import { CartContext } from "../context/CartContext"
import { useNavigate } from "react-router-dom"

export default function Cart() {
  const { cart, removeFromCart } = useContext(CartContext)
  const navigate = useNavigate()
  const total = cart.reduce((s,i)=>s+i.price,0)

  return (
    <div>
      <h1>Cart</h1>
      {cart.map((i,idx)=>(
        <p key={idx}>{i.title} - ₹{i.price}
        <button onClick={()=>removeFromCart(idx)}>X</button></p>
      ))}
      <h2>Total: ₹{total}</h2>
      <button onClick={()=>navigate("/checkout")}>Checkout</button>
    </div>
  )
}
