
export default function Success() {
  return <h1>Payment Successful</h1>
}
